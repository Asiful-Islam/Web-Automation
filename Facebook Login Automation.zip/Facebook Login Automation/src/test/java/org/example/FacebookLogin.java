package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class FacebookLogin extends BrowserSetup{
    @Test
    public void Facebook() throws InterruptedException {
        browser.get("https://www.google.com/");
        WebElement search_button = browser.findElement(By.id("APjFqb"));
        search_button.sendKeys("Facebook");
        search_button.submit();
        WebElement log_in = browser.findElement(By.linkText("Facebook Login"));
        log_in.click();
        WebElement email_number = browser.findElement(By.id("email"));
        email_number.sendKeys("01517120120");
        WebElement password = browser.findElement(By.id("pass"));
        password.sendKeys("12345");
        Thread.sleep(5000);
        WebElement login = browser.findElement(By.className("_xkt"));
        //WebElement login = browser.findElement(By.xpath("//button[@id='u_0_b_5U']"));
        login.click();
        Thread.sleep(5000);
    }
}
